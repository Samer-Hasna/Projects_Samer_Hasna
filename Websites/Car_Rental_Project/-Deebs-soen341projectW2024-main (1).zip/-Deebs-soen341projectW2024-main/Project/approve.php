<?php

require_once('connection.php');
$bookid = $_GET['id'];
$sql = "SELECT * FROM booking WHERE BOOK_Id=$bookid";
$result = mysqli_query($con, $sql);
$res = mysqli_fetch_assoc($result);
$car_id = $res['CAR_ID'];
$sql2 = "SELECT * FROM cars WHERE CAR_ID=$car_id";
$carres = mysqli_query($con, $sql2);
$carresult = mysqli_fetch_assoc($carres);
$email = $res['EMAIL'];
$carname = $carresult['CAR_NAME'];
if ($carresult['AVAILABLE'] == 'Y') {
    if ($res['BOOK_STATUS'] == 'APPROVED' || $res['BOOK_STATUS'] == 'RETURNED') {
        echo '<script>alert("ALREADY APPROVED")</script>';
        echo '<script>window.location.href = "adminbook.php";</script>';
    } else {
        $query = "UPDATE booking SET BOOK_STATUS='APPROVED' WHERE BOOK_ID=$bookid";
        $queryy = mysqli_query($con, $query);
        $sql2 = "UPDATE cars SET AVAILABLE='N' WHERE CAR_ID=$res[CAR_ID]";
        $query2 = mysqli_query($con, $sql2);

        if ($queryy && $query2) {
            $to_email = $email;
            $subject = "Car Rental Approval";
            $message = "Dear Customer,\n\nYour car booking with ID $bookid and booking date of $res[BOOK_DATE] has been approved. You have booked $carname. Below are the details:\n\nCar Name: $carname\nBooked Place: $res[DESTINATION]\nBooked Date: $res[BOOK_DATE]\nDuration: $res[DURATION]\nPhone Number: $res[PHONE_NUMBER]\nDestination: $res[DESTINATION]\nReturn Date: $res[RETURN_DATE]\n\nPlease refer to your online portal for more information. To access your rental agreement contract, click http://localhost/test_samer/agreement.php";
            $encoded_subject = rawurlencode($subject);
            $encoded_message = rawurlencode($message);
            echo "<a id='mailto-link' style='display:none;' href='mailto:$to_email?subject=$encoded_subject&body=$encoded_message'>Email</a>";
            echo "<script>document.getElementById('mailto-link').click();</script>";
            echo '<script>alert("APPROVED SUCCESSFULLY. Email sent to '.$to_email.'.")</script>';
            echo '<script>window.location.href = "adminbook.php";</script>';
        } else {
            echo '<script>alert("Failed to approve booking!")</script>';
            echo '<script>window.location.href = "adminbook.php";</script>';
        }
        exit; // Stop further execution
    }
} else {
    echo '<script>alert("CAR IS NOT AVAILABLE")</script>';
    echo '<script>window.location.href = "adminbook.php";</script>';
    exit; // Stop further execution
}

?>
