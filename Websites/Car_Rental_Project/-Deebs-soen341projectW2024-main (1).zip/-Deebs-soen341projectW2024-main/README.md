# -Deebs-soen341projectW2024
The project is a car rental application that will serve customers, customer service representatives , and system administrators. The application will facilitate the process of renting a car , whether it is for the short term or the long term. Customers will be able to browse cars , start a reservation on a car of their choice , find the nearest branch , and review or cancel a reservation. Customer service representatives will be able to create or override reservations, verify existing reservations, and confirm completion of rental agreements . System administrators shall be capable of performing CRUD operations on users, vehicles, and reservations. Overall, this project's goal is to streamline the process of car rental, whether it is on the provider and customer side , therefore reducing the downtime experienced between each reservation in the traditional rental process . Six experienced software developers from Concordia University will be in charge of the project, below is a short summary of each of their roles and responsibilities:
- Boudy Joe Samaha: Mr.Samaha will be our meetings leader and coordinator , and is also responsible for enabling online checkout for users on the website.
-  Peter Samaha: With 2 years of software engineering experience, Mr.Samaha will be responsible for implementing the renting interface (browse cars) .
-  Samer hasna : Mr.Hasna shall bring his extensive experience in website design , and will be responsible for styling and design .
-  Abdelrahman Alkhabbaz: As a backend engineer , Mr.Alkhabbaz shall implement the interface for CRUD operations and manage the user database.
-  Ali Eldeeb: Mr.Eldeeb shall collaborate with Mr.Alkhabbaz and implement both the customer service representative and system adminsitrator interfaces.
-  Abdelrahman Eldeeb: Mr.Eldeeb shall design and present the home page and login page for the system.

**Website video demo**: https://www.kapwing.com/w/TZd6w8eykH


Installation instructions:
1) Download xamPP and mysql.
2) Start apache and mysql inside the xampp control panel.
3) Place the website folder inside the following directory: "C:\xampp\htdocs"
4) To access the website , access the following link: http://localhost/Website/index.php

Additional rules and guidelines regarding the repository and contribution are posted on our [Wiki!](https://github.com/Samer-Hasna/-Deebs-soen341projectW2024/wiki)


